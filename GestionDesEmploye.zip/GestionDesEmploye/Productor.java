package employes;

public class Productor extends Employe {

	Productor(String nom, String prenom, int Age, String dateDES) {
		super(nom, prenom, Age, dateDES);
		// TODO Auto-generated constructor stub
	}

	public double calculerSalaire() {
		return 0;
	}

}
