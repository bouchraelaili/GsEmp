package employes;

public interface ProductionRisquesInterface {

	public double salaireFixeDeProducteur = 200;
}
