package employes;

public interface ManutentionRisquesInterface {

	public double salaireFixeDeManutionaire = 200;
}
